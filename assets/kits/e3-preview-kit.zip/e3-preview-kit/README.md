# E3 preview kit: the agent loop from scratch

The kit for steps 1 to 7 of E3's build, from the free preview of *Building AI Agents*:
https://defendingaiagents.com/learn/e03-agent-loop/build.html

You need Python 3.11 or later and [uv](https://docs.astral.sh/uv/). Nothing here needs a
model, Docker or the network after the first `uv` install.

```bash
make check-E3                        # fails: NotImplementedError in loop/
uv run pytest checks/test_checkE3.py -k schema    # one group at a time as you go
make loop-study PARTS=faults         # also herd, growth: model-free parts of the study
```

Without make: `CHECK_E3_OFFLINE=1 uv run pytest checks/test_checkE3.py`.

You implement eight pieces in `loop/` (the build page lists them). When all checks pass,
steps 1 to 7 are done. Steps 8 and 9 run your loop against Module 1's lab and a local model;
they need the full starter kit, which ships with the course.
