# E3 preview kit: the agent loop from scratch

The kit for steps 1 to 8 of E3's build, from the free preview of *Building AI Agents*:
https://defendingaiagents.com/learn/e03-agent-loop/build.html

You need Python 3.11 or later and [uv](https://docs.astral.sh/uv/). Nothing here needs a
model, Docker or the network after the first `uv` install, and nothing here contacts a lab.

```bash
make check-E3                        # fails: NotImplementedError in loop/
uv run pytest checks/test_checkE3.py -k schema    # one step's tests (groups below)
make loop-study PARTS=herd           # model-free parts of the study: herd, growth, faults
```

Without make: `uv run pytest checks/test_checkE3.py`.

You implement eight pieces in `loop/` (the build page lists them), one a step. Each step's
group runs exactly that step's tests: `-k schema` (step 1), `formats` (2), `parallel` (3),
`retry` (4), `budget` (5), `structured` (6), `stream` (7), `loop` (8). When all checks pass,
steps 1 to 8 are done; only the live test is skipped. Steps 9 and 10 run your loop against
Module 1's lab and a local model; they need the full starter kit, which ships with the course.
