"""Engineering track E3: the agent loop from scratch.

Module 1's agent (agent/agent.py) is a loop in under 100 lines. This package grows it into one you could run:

  client.py      provided  an OpenAI-compatible chat client that returns the message, its usage and its timing
  scripted.py    provided  a scripted client for tests: replies, usage, failures and stream chunks on cue
  formats.py     you       one tool call in three wire formats (OpenAI, Anthropic, Gemini), and adapters
  schema.py      you       parse and check a tool call's arguments, with errors a model can act on
  retry.py       you       which failures to retry, exponential backoff with full jitter, Retry-After
  budget.py      you       steps, tokens, cost and wall clock, and which one ran out
  parallel.py    you       run a turn's tool calls, reads in parallel, writes in order, results in call order
  structured.py  you       a final answer that must match a schema, with one repair attempt
  stream.py      you       reassemble a streamed reply, including tool calls sent in fragments
  agent.py       you       the loop that puts them together
  tasks.py       provided  twenty lab tasks with graders, for the study

Nothing here imports agent/ except the study, which runs Module 1's loop as the baseline. Module 1 stays untouched.
"""
