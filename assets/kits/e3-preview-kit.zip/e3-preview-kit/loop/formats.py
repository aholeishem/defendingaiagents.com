"""E3 lesson 3: one tool call in three wire formats, and adapters between them.

The loop speaks one format inside, OpenAI Chat Completions, because every local server (Ollama, llama.cpp,
vLLM, LM Studio) serves it. Hosted APIs have their own. The same call, "read notes/a.txt", in each:

  Chat Completions   message.tool_calls = [{"id": "call_1", "type": "function",
                                            "function": {"name": "read_file", "arguments": "{\\"path\\": \\"notes/a.txt\\"}"}}]
                     result: {"role": "tool", "tool_call_id": "call_1", "content": "..."}
                     tools:  [{"type": "function", "function": {"name", "description", "parameters"}}]

  Responses          output = [{"type": "function_call", "call_id": "call_1", "name": "read_file",
                                "arguments": "{\\"path\\": \\"notes/a.txt\\"}"}]
                     result: {"type": "function_call_output", "call_id": "call_1", "output": "..."}
                     tools:  [{"type": "function", "name", "description", "parameters"}]           (flat)

  Anthropic Messages content = [{"type": "tool_use", "id": "toolu_1", "name": "read_file",
                                 "input": {"path": "notes/a.txt"}}]
                     result: {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "toolu_1",
                                                          "content": "..."}]}
                     tools:  [{"name", "description", "input_schema"}]

Three differences carry bugs: arguments are a JSON *string* in the two OpenAI formats and an *object* in
Anthropic's; the system prompt is a message in Chat Completions and a top-level field in Anthropic's; and
Anthropic has no tool role: results are user content blocks, and all the results of one assistant turn go in
one user message, first in its content. Anthropic's documentation is explicit that one message per result
"teaches" the model to stop making parallel calls: the history is a few-shot prompt, including its format.

Provided: to_responses_tools, from_responses_output.
You implement: to_anthropic_tools, to_anthropic_request, from_anthropic_response.
"""
from __future__ import annotations

import json

# ── OpenAI Responses (provided: read it, then write the Anthropic adapters) ──


def to_responses_tools(tools: list[dict]) -> list[dict]:
    return [{"type": "function", "name": t["function"]["name"], "description": t["function"].get("description", ""),
             "parameters": t["function"].get("parameters", {"type": "object", "properties": {}})} for t in tools]


def from_responses_output(output: list[dict]) -> dict:
    """A Responses API `output` list as one Chat Completions assistant message."""
    text, calls = [], []
    for item in output:
        if item.get("type") == "message":
            text += [c.get("text", "") for c in item.get("content", []) if c.get("type") == "output_text"]
        elif item.get("type") == "function_call":
            calls.append({"id": item["call_id"], "type": "function",
                          "function": {"name": item["name"], "arguments": item.get("arguments") or "{}"}})
    msg = {"role": "assistant", "content": "".join(text)}
    if calls:
        msg["tool_calls"] = calls
    return msg


# ── Anthropic Messages ───────────────────────────────────────────────────────


def to_anthropic_tools(tools: list[dict]) -> list[dict]:
    """Chat Completions tool schemas -> Anthropic's: {"name", "description", "input_schema"}."""
    raise NotImplementedError("Module E3: implement to_anthropic_tools")


def to_anthropic_request(messages: list[dict], tools: list[dict], model: str, max_tokens: int = 1024) -> dict:
    """A Chat Completions history -> an Anthropic Messages request body.

    - system messages are joined (blank line between) into the top-level "system" field, and leave the list;
    - a user message with string content stays {"role": "user", "content": text};
    - an assistant message becomes content blocks: a {"type": "text"} block if it has text, then one
      {"type": "tool_use", "id", "name", "input"} block per tool call, with the arguments string parsed to an
      object; {} if it is empty, and {} if it does not parse to an object (run keeps a refused, malformed call
      in the history, and the tool_result after it already says what was wrong);
    - consecutive tool messages become ONE user message whose content is their
      {"type": "tool_result", "tool_use_id", "content"} blocks, in order.
    The body has "model", "max_tokens", "messages", "system" only if there was a system message, and "tools"
    (via to_anthropic_tools) only if there are tools."""
    raise NotImplementedError("Module E3: implement to_anthropic_request")


def from_anthropic_response(resp: dict) -> tuple[dict, dict]:
    """An Anthropic Messages response -> (Chat Completions assistant message, usage).

    Text blocks are joined into "content" ("" if none); each tool_use block becomes a tool call whose arguments
    are its input serialised with json.dumps; "tool_calls" is present only if there are any. Usage maps
    input_tokens -> prompt_tokens and output_tokens -> completion_tokens."""
    raise NotImplementedError("Module E3: implement from_anthropic_response")
