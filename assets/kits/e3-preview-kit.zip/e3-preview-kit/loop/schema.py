"""E3 lesson 2: a tool is a schema, a function and an error message, and the model reads all three.

A model writes a tool call's arguments as text. Two things can be wrong with that text, and the loop must tell
the model which, in words it can act on:

  1. It is not JSON at all (a truncated object, a trailing comma, single quotes).       parse_arguments
  2. It is JSON, but not what the schema asked for (a missing field, a number as text).  check_arguments

Both errors go back to the model as the tool's result, and the tool never runs. Module 1's loop did neither: a
malformed string crashed it at json.loads, and a wrong argument reached the tool.

check_arguments covers the part of JSON Schema that tool definitions use: type, properties, required,
additionalProperties: false, enum, and items for arrays. Anything else in a schema is ignored, not failed.

Provided: TYPES.
You implement: parse_arguments, check_arguments.
"""
from __future__ import annotations

import json

# JSON Schema type -> the Python types that satisfy it. bool is excluded from the numbers on purpose:
# in Python True == 1, in JSON true is not a number.
TYPES = {"object": (dict,), "array": (list,), "string": (str,), "integer": (int,), "number": (int, float),
         "boolean": (bool,), "null": (type(None),)}


def parse_arguments(raw) -> tuple[dict | None, str | None]:
    """(arguments, None) if `raw` is a JSON object or already a dict; (None, error) otherwise.

    OpenAI-format servers send arguments as a JSON string; Anthropic and Gemini send an object; some servers send
    an empty string for a call with no arguments, which means {}. The error names what was wrong and where, e.g.
    "arguments are not valid JSON: Expecting ',' delimiter at character 17", or "arguments must be a JSON object,
    got list"."""
    raise NotImplementedError("Module E3: implement parse_arguments")


def _is(value, type_name: str) -> bool:
    if type_name in ("integer", "number") and isinstance(value, bool):
        return False
    if type_name == "integer" and isinstance(value, float):
        return value.is_integer()
    return isinstance(value, TYPES.get(type_name, (object,)))


def check_arguments(schema: dict, args, path: str = "") -> list[str]:
    """Every way `args` fails `schema`, as one short sentence each, naming the field by its path ("to",
    "items[2].sku"). An empty list means the arguments are acceptable.

    Messages, so that the tests and a model can rely on them:
      "missing required field 'to'"
      "'count' must be integer, got string"
      "unexpected field 'cc' (allowed: body, subject, to)"
      "'priority' must be one of ['high', 'low'], got 'urgent'"
    """
    raise NotImplementedError("Module E3: implement check_arguments")


def _join(path: str, name: str) -> str:
    return f"{path}.{name}" if path else name


def _json_type(v) -> str:
    if isinstance(v, bool):
        return "boolean"
    for name in ("null", "object", "array", "string", "integer", "number"):
        if isinstance(v, TYPES[name]):
            return name
    return type(v).__name__
