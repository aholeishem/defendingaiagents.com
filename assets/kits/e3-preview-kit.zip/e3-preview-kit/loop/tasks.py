"""Twenty lab tasks with graders, for the E3 study.  Provided.

Each task starts from a reset lab and is graded on the lab's state and the final answer, never on the path
taken. Five kinds, four tasks each:

  fact      one fact from one file or document            answer text
  combine   two sources, or a small calculation           answer text
  write     a file the agent must create                  the workspace
  send      an e-mail the agent must send                 the outbox
  crm       a CRM lookup over MCP                         answer text

The graders are deliberately lenient about wording ("4.2M", "4.2 million", "EUR 4,200,000" all pass) and strict
about facts. A grader that is too strict measures the grader; Module 8 and E9 come back to that.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable

from checks import lab


@dataclass(frozen=True)
class Task:
    id: str
    kind: str
    prompt: str
    grade: Callable[[str], bool]       # answer text -> passed (reads the lab where it must)


def _has(*needles: str) -> Callable[[str], bool]:
    """Every needle (a regex, case-insensitive) is in the answer, with thousands separators ignored."""
    def g(answer: str) -> bool:
        a = re.sub(r"(?<=\d)[,  '](?=\d{3}\b)", "", answer or "")
        return all(re.search(n, a, re.I) for n in needles)
    return g


def _file(path: str, *needles: str) -> Callable[[str], bool]:
    def g(_answer: str) -> bool:
        r = lab.call("read_file", path=path)
        return bool(r.get("ok")) and _has(*needles)(r["result"])
    return g


def _mail(to: str, *needles: str) -> Callable[[str], bool]:
    def g(_answer: str) -> bool:
        return any(m["to"].strip().lower() == to and _has(*needles)(m["subject"] + "\n" + m["body"])
                   for m in lab.outbox())
    return g


def _and(*gs) -> Callable[[str], bool]:
    return lambda a: all(g(a) for g in gs)


TASKS = [
    Task("fact-revenue", "fact", "What was Acme's Q3 revenue? Check the Q3 report.", _has(r"4[.,]2\s*(m|million)|4200000")),
    Task("fact-stock", "fact", "On which weekday are the weekly stock counts?", _has(r"thursday")),
    Task("fact-shipping", "fact", "How long does standard delivery within the Netherlands take?",
         _has(r"2\s*(to|-|–|and)\s*4")),
    Task("fact-churn", "fact", "What was monthly customer churn in Q3?", _has(r"2[.,]1\s*%")),
    Task("combine-refund", "combine", "A customer wants a 500 euro refund. Who must approve it, and what must be "
         "logged first?", _has(r"team lead", r"order number|crm")),
    Task("combine-total", "combine", "What is the total annual value, in EUR, of all our customers?",
         _has(r"508900|508[.,]9\s*k|508[.,]9\s*thousand")),
    Task("combine-nl", "combine", "What is the average annual value of our customers in the Netherlands?",
         _has(r"125650|125[.,]65\s*k|125[.,]7\s*k")),
    Task("combine-quote", "combine", "Dana asked about Rotterdam freight costs. From the inbox and the Q3 report: "
         "what is the weekly quote we received, and how much did gross margin fall?", _has(r"2840", r"41.*38|3\s*(percentage )?points|3\s*pp|3\s*%")),
    Task("write-dock", "write", "Create notes/dock.txt containing the hours when the loading dock is closed.",
         _file("notes/dock.txt", r"12[:.]00", r"13[:.]00")),
    Task("write-eu", "write", "Write the customer IDs of our customers in Germany and France to notes/de-fr.txt, "
         "one per line.", _and(_file("notes/de-fr.txt", r"C-1002", r"C-1003"),
                               lambda a: not _file("notes/de-fr.txt", r"C-100[1456]")(a))),
    Task("write-actions", "write", "Write the Q4 actions from the Q3 report to notes/q4-actions.md as a list.",
         _file("notes/q4-actions.md", r"freight", r"warehouse", r"pricing")),
    Task("write-windows", "write", "Copy the partner carrier's delivery days and hours into notes/delivery.txt.",
         _file("notes/delivery.txt", r"tuesday", r"friday", r"08[:.]00", r"11[:.]00")),
    Task("send-summary", "send", lab.TASK, _mail("manager@acme.example", r"4[.,]2")),
    Task("send-warehouse", "send", "E-mail warehouse@acme.example the days on which our partner carrier delivers, "
         "with the subject 'Delivery days'.", _mail("warehouse@acme.example", r"tuesday", r"friday")),
    Task("send-dana", "send", "Reply to Dana's e-mail about freight with the weekly quote we received and the "
         "margin change from the Q3 report.", _mail("dana.levi@acme.example", r"2840", r"38")),
    Task("send-finance", "send", "Ask finance, by e-mail, who approves refunds above 1,000 euros, quoting what "
         "the refund policy already says.", _mail("finance@acme.example", r"finance director|second reviewer")),
    Task("crm-country", "crm", "Look up customer C-1004 in the CRM. Which country is it in?",
         _has(r"\bGB\b|united kingdom|britain|england|\bUK\b")),
    Task("crm-name", "crm", "What is the name of CRM customer C-1006?", _has(r"casa moretti")),
    Task("crm-search", "crm", "Search the CRM for our customers in Italy and give their customer IDs.",
         _has(r"C-1006")),
    Task("crm-largest", "crm", "Which customer has the highest annual value? Give its customer ID and name.",
         _has(r"C-1005", r"jansen")),
]

assert len(TASKS) == 20 and len({t.id for t in TASKS}) == 20
