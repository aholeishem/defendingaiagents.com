"""E3 lesson 8: streaming, and why a streamed tool call is half a JSON object.

With "stream": true an OpenAI-compatible server sends server-sent events, one JSON chunk per line:

  data: {"choices":[{"index":0,"delta":{"role":"assistant","content":"The "}}]}
  data: {"choices":[{"index":0,"delta":{"content":"total is"}}]}
  data: {"choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_1","type":"function",
                                          "function":{"name":"read_file","arguments":""}}]}}]}
  data: {"choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{\\"pa"}}]}}]}
  data: {"choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"th\\": \\"a\\"}"}}]}}]}
  data: {"choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}]}
  data: {"choices":[],"usage":{"prompt_tokens":140,"completion_tokens":31}}
  data: [DONE]

Text arrives in pieces that are each meaningful. A tool call's arguments arrive in pieces that are not: no
prefix of a JSON object is a JSON object. The loop may show text as it comes, but it may act on a tool call only
after the stream has ended and the call's arguments have been put back together. Each tool call carries an
`index`; its id and name come in its first fragment, its arguments are the concatenation of every fragment's.

Servers differ: OpenAI's API sends arguments in fragments; Ollama sends each call whole in one chunk (measured,
lesson 8). An assembler written for the second breaks on the first. Write it for the first.

Provided: sse_events.
You implement: assemble.
"""
from __future__ import annotations

import json


def sse_events(lines):
    """Yield the JSON payload of each `data:` line, until `data: [DONE]`. Blank lines and comments are skipped."""
    for line in lines:
        line = line.strip()
        if not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if data == "[DONE]":
            return
        yield json.loads(data)


def assemble(chunks: list[dict]) -> dict:
    """The assistant message the chunks spell, in the non-streamed format:
    {"role": "assistant", "content": <all content deltas joined, "" if none>,
     "tool_calls": [{"id", "type": "function", "function": {"name", "arguments"}}, ...]}   (key only if any)

    Tool calls are ordered by `index`. For each index: id, type and name are taken from the first fragment that
    has them; `arguments` is every fragment's arguments joined in arrival order. Chunks with no choices (the
    final usage chunk) are skipped."""
    raise NotImplementedError("Module E3: implement assemble")
