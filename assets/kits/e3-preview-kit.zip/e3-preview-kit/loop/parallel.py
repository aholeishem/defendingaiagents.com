"""E3 lesson 4: parallel tool calls and their ordering.

A model may ask for several tool calls in one turn. Two rules decide how to run them:

  1. Results go back in the order the model asked, each with its own call id. The model matches results to
     calls by id, but some servers and many models also lean on the order, and a log that interleaves them is
     hard to read.
  2. Only calls that are safe to reorder run concurrently. Two reads commute; a write and a read of the same
     file do not, and two e-mails sent in either order are two different histories. A call that is not in
     `parallel_safe` is a barrier: everything asked before it finishes before it starts, and everything after it
     starts after it ends.

"Safe to reorder" is not "safe". fetch_url changes nothing in the lab and commutes with any read, so it can run
in parallel, and it is also a way out of the lab (Module 1, lesson 6; Module 11). Parallelism is a property of
the effects, security of the information flow.

Before any call runs, its arguments are parsed and checked (loop.schema), and a call to an unknown tool is
refused. A refused or failed call becomes an error string the model reads, never an exception in the loop.

Provided: READ_ONLY, ToolCall, prepare.
You implement: execute.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass

from loop.schema import check_arguments, parse_arguments

# The lab tools that change nothing (Module 1, lesson 6), plus the CRM's two reads.
READ_ONLY = frozenset({"list_files", "read_file", "read_inbox", "search_docs", "recall", "fetch_url",
                       "crm__lookup_customer", "crm__search_customers"})


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict | None      # None when they would not parse or check
    error: str | None           # why the call is refused, if it is


def prepare(call: dict, schemas: dict[str, dict]) -> ToolCall:
    """Parse and check one OpenAI-format tool call against the tools' parameter schemas (name -> schema)."""
    fn = call.get("function") or {}
    name, cid = fn.get("name", ""), call.get("id") or f"call_{fn.get('name', '')}"
    if name not in schemas:
        return ToolCall(cid, name, None, f"ERROR: no tool named '{name}'. Available: {', '.join(sorted(schemas))}")
    args, err = parse_arguments(fn.get("arguments"))
    if err:
        return ToolCall(cid, name, None, f"ERROR: {name}: {err}. Call it again with a JSON object.")
    problems = check_arguments(schemas[name], args)
    if problems:
        return ToolCall(cid, name, None, f"ERROR: {name}: invalid arguments: {'; '.join(problems)}.")
    return ToolCall(cid, name, args, None)


def _run_one(call: ToolCall, tools) -> str:
    if call.error:
        return call.error
    try:
        return str(tools.call(call.name, call.arguments))
    except Exception as e:  # noqa: BLE001  (a tool's failure is the model's information, not the loop's crash)
        return f"ERROR: {call.name} failed: {e.__class__.__name__}: {e}"


def execute(calls: list[ToolCall], tools, parallel_safe=READ_ONLY, max_workers: int = 4) -> list[dict]:
    """Run the calls and return one tool message per call, in the calls' order:
    {"role": "tool", "tool_call_id": call.id, "content": result}.

    Consecutive calls whose names are in parallel_safe run together in a thread pool of max_workers; any other
    call runs alone, after the calls before it and before the calls after it. A refused call (call.error set)
    is not run: its error is its result. A tool that raises becomes "ERROR: <name> failed: <Type>: <message>"."""
    raise NotImplementedError("Module E3: implement execute")
