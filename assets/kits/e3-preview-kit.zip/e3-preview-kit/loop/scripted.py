"""A scripted chat client for tests: deterministic, instant, no model server.  Provided.

Each script item is one of:
  a message dict                     returned as the reply (with `usage` charged, default 100 in / 20 out)
  an Exception instance              raised instead of replying (to test retries)
  ("chunks", [chunk, ...])           a streamed reply: complete(stream=True) assembles these with loop.stream;
                                     complete(stream=False) raises AssertionError, since the reply was not asked for
                                     as a stream

Every request is recorded in `seen` (a copy of the messages), so a test can check what the model was shown.
"""
from __future__ import annotations

import json

from loop.client import Reply


def tool_call(name: str, call_id: str | None = None, raw: str | None = None, **arguments) -> dict:
    """An assistant message with one tool call. `raw` sends the arguments string as is (to test malformed JSON)."""
    return tool_calls((name, raw if raw is not None else json.dumps(arguments), call_id))


def tool_calls(*calls) -> dict:
    """An assistant message with several tool calls: each call is (name, arguments as a JSON string[, id])."""
    out = []
    for i, c in enumerate(calls):
        name, args = c[0], c[1]
        cid = c[2] if len(c) > 2 and c[2] else f"call_{i}_{name}"
        out.append({"id": cid, "type": "function", "function": {"name": name, "arguments": args}})
    return {"role": "assistant", "content": "", "tool_calls": out}


def answer(text: str) -> dict:
    return {"role": "assistant", "content": text}


class ScriptedClient:
    def __init__(self, script: list, usage: dict | None = None, seconds: float = 0.0):
        self.script, self.seen, self.calls = list(script), [], 0
        self.usage = usage or {"prompt_tokens": 100, "completion_tokens": 20}
        self.seconds = seconds

    def complete(self, messages: list[dict], tools: list[dict], stream: bool = False) -> Reply:
        self.calls += 1
        self.seen.append(json.loads(json.dumps(messages)))
        item = self.script.pop(0) if self.script else answer("[script ended]")
        if isinstance(item, BaseException):
            raise item
        if isinstance(item, tuple) and item[0] == "chunks":
            if not stream:
                raise AssertionError("this reply is scripted as a stream, but complete() was called with stream=False")
            from loop.stream import assemble
            return Reply(assemble(item[1]), dict(self.usage), self.seconds, ttft=0.0)
        return Reply(json.loads(json.dumps(item)), dict(self.usage), self.seconds)
