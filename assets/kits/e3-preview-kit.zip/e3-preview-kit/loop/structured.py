"""E3 lesson 7: a final answer that a program can read.

When the caller is a program, "Done, the total is about half a million" is a failure. The caller passes a JSON
Schema for the answer; the loop asks for JSON, finds it in the reply, checks it, and if it does not check, sends
the errors back and asks once more. One repair, not a loop: a model that fails twice on the same schema has
told you something about the schema or the model, and a third try mostly spends tokens (lesson 7 measures it).

Models wrap JSON in prose and code fences. extract_json takes the first complete JSON object or array in the
text, fenced or not, which is what a person reading the reply would take.

Constrained decoding (E2) makes the model unable to write anything but valid JSON. This is the check for the
servers and models where you do not have it, and for the schema rules a grammar does not capture.

Provided: instruction, repair_message.
You implement: extract_json, parse_final.
"""
from __future__ import annotations

import json
import re

from loop.schema import check_arguments


def instruction(schema: dict) -> str:
    return ("When you have finished, reply with only a JSON value that matches this JSON Schema, and nothing else:\n"
            + json.dumps(schema, ensure_ascii=False))


def repair_message(errors: list[str]) -> dict:
    return {"role": "user", "content": "Your final answer did not match the schema: " + "; ".join(errors)
            + ". Reply again with only the corrected JSON."}


FENCE = re.compile(r"```(?:json)?\s*(.*?)```", re.S)


def extract_json(text: str):
    """The first JSON object or array in `text`: inside a ``` or ```json fence if there is one, else the first
    '{' or '[' from which a complete JSON value decodes (json.JSONDecoder.raw_decode). Raise ValueError if none."""
    raise NotImplementedError("Module E3: implement extract_json")


def parse_final(text: str, schema: dict) -> tuple[object | None, list[str]]:
    """(value, []) if the reply holds JSON that checks against the schema; (None, errors) otherwise, with
    "no JSON object or array in the reply" as the one error when there is no JSON at all."""
    raise NotImplementedError("Module E3: implement parse_final")
