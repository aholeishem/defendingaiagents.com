"""E3: the loop, put together.  Run it:

  uv run python -m loop.agent "Read notes/q3-report.txt and e-mail a summary to manager@acme.example."

Module 1's loop, step by step, with what this one adds:

  1. before each model call, check the budget; stop with its name if one ran out     (budget.py)
  2. call the model, retrying the failures worth retrying                            (retry.py)
  3. no tool calls: that is the answer; check it against answer_schema if given,
     and ask for one repair if it does not check                                     (structured.py)
  4. tool calls: parse and check each one, run them, reads in parallel,
     results in the order asked                                                      (schema.py, parallel.py)
  5. go to 1

The result says how the run ended (stop), what it cost (usage) and every call made (calls), because "it
returned a string" is not enough to know whether it worked.

Provided: SYSTEM, Result, log helpers, main.
You implement: run.
"""
from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field

from loop.budget import Budget
from loop.parallel import READ_ONLY, execute, prepare
from loop.retry import call_with_retries
from loop.structured import instruction, parse_final, repair_message

SYSTEM = ("You are the operations assistant at Acme Widgets. You act for the user, "
          "using the tools provided. Today is 2026-10-12. Be brief.")     # Module 1's, word for word


@dataclass
class Result:
    stop: str                       # "answer", "steps", "tokens", "cost", "seconds", "error", "schema"
    answer: str | None = None       # the final text, if the model gave one
    data: object = None             # the parsed answer, when answer_schema was given and it checked
    usage: dict = field(default_factory=dict)          # Budget.spent()
    calls: list = field(default_factory=list)          # (name, arguments or None, result) per tool call
    messages: list = field(default_factory=list)       # the whole history, for the record
    error: str | None = None        # what failed, when stop == "error" or "schema"
    repairs: int = 0                # schema repairs asked for


def quiet(*_):
    pass


def run(task: str, model, tools, budget: Budget | None = None, answer_schema: dict | None = None,
        parallel_safe=READ_ONLY, stream: bool = False, retry: dict | None = None, log=quiet,
        system: str | None = None) -> Result:
    """Run the task to an answer or a limit.

    model:  has complete(messages, tools, stream) -> loop.client.Reply (ChatClient, ScriptedClient)
    tools:  has .schemas (Chat Completions tool list) and .call(name, arguments) -> str (agent.agent.Tools)
    budget: a fresh Budget(); default Budget(max_steps=10), which is Module 1's only limit
    retry:  keyword arguments for call_with_retries (max_attempts, base, cap, sleep, rng)

    system: replaces SYSTEM as the system prompt (E2, E5 use it)

    The messages start with the system prompt (SYSTEM unless system is given), then the task; if answer_schema is given, instruction(answer_schema) is added
    to the system message. Each model call is charged to the budget with the reply's usage. Stops:
      "answer"   the model replied without tool calls (and, with a schema, the reply checked)
      "schema"   with a schema, the reply did not check after one repair; error lists why
      a budget limit's name, when exceeded() says so before a model call
      "error"    the model call failed for good (after retries); error is "<Type>: <message>"
    Each tool call is recorded in calls as (name, parsed arguments or None if refused, result text)."""
    raise NotImplementedError("Module E3: implement run")


def main() -> None:
    from agent.agent import Tools
    from loop.client import ChatClient
    r = run(" ".join(sys.argv[1:]), ChatClient(), Tools(), Budget(max_steps=10, max_tokens=60_000), log=print)
    print(f"[{r.stop}] {r.answer or r.error or ''}")
    print(json.dumps(r.usage))


if __name__ == "__main__":
    main()
