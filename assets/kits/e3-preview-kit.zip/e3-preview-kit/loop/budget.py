"""E3 lesson 6: budgets and stopping.

Module 1's only limit is max_steps. A step is not a unit of cost: one step can be 300 tokens or 30,000 (a long
file read, a model that thinks for a page), and a reasoning model's thinking is billed as output. A loop that
runs unattended needs four limits, checked before every model call, and it must say which one stopped it:

  steps     model calls                          the runaway loop
  tokens    prompt + completion, summed          the context that grows every step
  cost      tokens at a price per million        the bill (zero on a laptop; a price makes it visible)
  seconds   wall clock since start               the user who is waiting

The prompt is re-sent in full each step, so a run's prompt tokens grow roughly quadratically in its steps:
step t sends everything from steps 1..t-1 again. That is why a token budget runs out long before a step budget
on a task that reads files.

Provided: the dataclass fields and spent().
You implement: start, charge, exceeded.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class Budget:
    max_steps: int = 10
    max_tokens: int | None = None
    max_cost: float | None = None           # in the currency of the prices
    max_seconds: float | None = None
    price_in: float = 0.0                   # per million prompt tokens
    price_out: float = 0.0                  # per million completion tokens
    clock: object = time.monotonic
    steps: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    started: float | None = field(default=None)

    def spent(self) -> dict:
        return {"steps": self.steps, "prompt_tokens": self.prompt_tokens,
                "completion_tokens": self.completion_tokens, "cost": round(self.cost(), 6),
                "seconds": round(self.elapsed(), 3)}

    def cost(self) -> float:
        return (self.prompt_tokens * self.price_in + self.completion_tokens * self.price_out) / 1e6

    def elapsed(self) -> float:
        return 0.0 if self.started is None else self.clock() - self.started

    def start(self) -> None:
        """Start the clock (once: a second call keeps the first start)."""
        raise NotImplementedError("Module E3: implement start")

    def charge(self, usage: dict) -> None:
        """Count one model call: one step, and its prompt and completion tokens (missing counts are zero)."""
        raise NotImplementedError("Module E3: implement charge")

    def exceeded(self) -> str | None:
        """The first limit reached, in the order steps, tokens, cost, seconds, or None. A limit is reached when
        what has been spent is at or above it: with max_steps=3, three charged calls leave no room for a fourth."""
        raise NotImplementedError("Module E3: implement exceeded")
