"""A chat client for any OpenAI-compatible server (Ollama, llama.cpp, vLLM, LM Studio, a hosted API).  Provided.

Module 1's Model.chat returns the message and drops everything else. This one keeps what the loop needs to
budget and to retry: token usage, wall-clock time, time to the first streamed byte, and the HTTP status of a
failure with its Retry-After.

  client = ChatClient()                      # AGENT_BASE_URL, AGENT_MODEL, as in Module 1
  reply = client.complete(messages, tools)   # Reply(message, usage, seconds, ttft)
"""
from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass, field

import httpx

BASE_URL = os.environ.get("AGENT_BASE_URL", "http://localhost:11434/v1")
MODEL = os.environ.get("AGENT_MODEL", "qwen3:4b")


@dataclass
class Reply:
    message: dict                                   # an assistant message in the OpenAI format
    usage: dict = field(default_factory=dict)       # prompt_tokens, completion_tokens (zero if the server sent none)
    seconds: float = 0.0                            # request to last byte
    ttft: float | None = None                       # request to first content or tool-call byte, when streamed


class ModelHTTPError(Exception):
    """The server answered with an error status. retry_after is in seconds, if the server sent one."""

    def __init__(self, status: int, body: str = "", retry_after: float | None = None):
        super().__init__(f"model server answered {status}: {body[:200]}")
        self.status, self.body, self.retry_after = status, body, retry_after


def _retry_after(r: httpx.Response) -> float | None:
    v = r.headers.get("retry-after")
    try:
        return float(v) if v is not None else None
    except ValueError:      # an HTTP date: rare from model servers; treated as absent
        return None


def _clean(msg: dict) -> dict:
    """Thinking is not part of the answer: Ollama puts it in `reasoning`, some servers inline <think> tags."""
    msg = {k: v for k, v in msg.items() if k not in ("reasoning", "reasoning_content")}
    text = re.sub(r"<think>.*?</think>", "", msg.get("content") or "", flags=re.S)
    if "</think>" in text:      # thinking that leaked without its opening tag (seen with reasoning_effort "none")
        text = text.rsplit("</think>", 1)[1]
    msg["content"] = text.strip()
    return msg


def _usage(u: dict | None) -> dict:
    u = u or {}
    return {"prompt_tokens": int(u.get("prompt_tokens") or 0), "completion_tokens": int(u.get("completion_tokens") or 0)}


class ChatClient:
    def __init__(self, base_url: str = BASE_URL, model: str = MODEL, temperature: float = 0.7,
                 timeout: float = float(os.environ.get("AGENT_TIMEOUT", "300")), clock=time.monotonic):
        self.http, self.model, self.temperature, self.clock = (
            httpx.Client(base_url=base_url, timeout=timeout), model, temperature, clock)

    def _body(self, messages, tools, stream):
        body = {"model": self.model, "messages": messages, "temperature": self.temperature}
        if tools:
            body["tools"] = tools
        if stream:
            body |= {"stream": True, "stream_options": {"include_usage": True}}
        return body

    def complete(self, messages: list[dict], tools: list[dict], stream: bool = False) -> Reply:
        """One model call. Raises httpx.TransportError (timeouts, refused connections) or ModelHTTPError."""
        t0 = self.clock()
        if not stream:
            r = self.http.post("/chat/completions", json=self._body(messages, tools, False))
            if r.status_code >= 400:
                raise ModelHTTPError(r.status_code, r.text, _retry_after(r))
            d = r.json()
            return Reply(_clean(d["choices"][0]["message"]), _usage(d.get("usage")), self.clock() - t0)
        from loop.stream import assemble, sse_events
        chunks, ttft = [], None
        with self.http.stream("POST", "/chat/completions", json=self._body(messages, tools, True)) as r:
            if r.status_code >= 400:
                r.read()
                raise ModelHTTPError(r.status_code, r.text, _retry_after(r))
            for event in sse_events(r.iter_lines()):
                delta = (event.get("choices") or [{}])[0].get("delta") or {}
                if ttft is None and (delta.get("content") or delta.get("tool_calls")):
                    ttft = self.clock() - t0
                chunks.append(event)
        if not any(ch.get("finish_reason") for c in chunks for ch in c.get("choices") or []):
            # The stream ended without saying it was finished: a dropped connection, not a reply. A partial tool
            # call must never be acted on, so this is a failed call, retried like any other (lesson 8).
            raise httpx.RemoteProtocolError("stream ended before a finish_reason")
        usage = next((c["usage"] for c in reversed(chunks) if c.get("usage")), None)
        return Reply(_clean(assemble(chunks)), _usage(usage), self.clock() - t0, ttft)


class LegacyAdapter:
    """Module 1's run() calls model.chat(messages, tools) -> message. This wraps a ChatClient so that the Module 1 loop
    can be measured with the same server and settings, and records the usage that Module 1 throws away."""

    def __init__(self, client: ChatClient):
        self.client, self.usage, self.calls = client, {"prompt_tokens": 0, "completion_tokens": 0}, 0

    def chat(self, messages: list[dict], tools: list[dict]) -> dict:
        reply = self.client.complete(messages, tools)
        self.calls += 1
        for k in self.usage:
            self.usage[k] += reply.usage.get(k, 0)
        return reply.message


def dumps(obj) -> str:
    return json.dumps(obj, ensure_ascii=False)
