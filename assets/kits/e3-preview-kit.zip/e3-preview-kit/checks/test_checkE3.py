"""make check-E3: the agent loop from scratch (engineering track, E3).

Groups, each testing behaviour with a scripted model and fake tools (no lab, no model), except the last. Each
group's name is in its tests' names and in no other test's, so `-k <group>` runs exactly one build step's tests:
  schema      malformed and mistyped arguments become errors the model can read          (step 1)
  formats     the same tool call in Chat Completions and Anthropic Messages, both ways   (step 2)
  parallel    reads run together, writes in order, results in the order asked            (step 3)
  retry       the right failures are retried, with full-jitter backoff and Retry-After   (step 4)
  budget      steps, tokens, cost and seconds, and which ran out first                   (step 5)
  structured  a final answer checked against a schema, with one repair                   (step 6)
  stream      a streamed reply reassembled, tool-call fragments included                 (step 7)
  loop        the loop puts them together                                                (step 8)
  live        your loop finishes the Module 1 task on your local model                   (step 9)

The live test resets the lab at TOOLS_URL, so it runs only when asked: CHECK_E3_LIVE=1 (or AGENT_BASE_URL) and
TOOLS_URL both set, with Module 1's agent/ in the kit. Otherwise it is skipped, and says why.
"""
from __future__ import annotations

import importlib.util
import json
import os
import random
import threading
import time

import httpx
import pytest

from loop import formats
from loop.agent import SYSTEM, run
from loop.budget import Budget
from loop.client import ModelHTTPError
from loop.parallel import ToolCall, execute, prepare
from loop.retry import backoff, call_with_retries, classify
from loop.schema import check_arguments, parse_arguments
from loop.scripted import ScriptedClient, answer, tool_call, tool_calls
from loop.stream import assemble
from loop.structured import extract_json, parse_final

READ = {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"],
        "additionalProperties": False}
SEND = {"type": "object", "properties": {"to": {"type": "string"}, "subject": {"type": "string"},
                                         "body": {"type": "string"}},
        "required": ["to", "subject", "body"], "additionalProperties": False}


class FakeTools:
    """In-memory tools: read_file and list_files are reads, send_email and write_file are writes."""

    def __init__(self, delay: float = 0.0):
        self.files = {"a.txt": "alpha", "b.txt": "beta"}
        self.sent, self.log, self.delay, self.lock = [], [], delay, threading.Lock()
        self.active, self.peak = 0, 0
        s = lambda n, p: {"type": "function", "function": {"name": n, "description": n, "parameters": p}}
        self.schemas = [s("read_file", READ), s("list_files", {"type": "object", "properties": {}}),
                        s("send_email", SEND), s("write_file", {"type": "object", "properties": {
                            "path": {"type": "string"}, "content": {"type": "string"}}, "required": ["path", "content"]})]

    def call(self, name, arguments):
        with self.lock:
            self.active += 1
            self.peak = max(self.peak, self.active)
            self.log.append(("start", name, arguments.get("path") or arguments.get("to")))
        try:
            time.sleep(self.delay)
            if name == "read_file":
                if arguments["path"] not in self.files:
                    raise FileNotFoundError(arguments["path"])
                return self.files[arguments["path"]]
            if name == "list_files":
                return "\n".join(sorted(self.files))
            if name == "write_file":
                self.files[arguments["path"]] = arguments["content"]
                return "ok"
            self.sent.append(arguments)
            return "sent"
        finally:
            with self.lock:
                self.active -= 1
                self.log.append(("end", name, arguments.get("path") or arguments.get("to")))


NO_SLEEP = {"sleep": lambda s: None, "rng": random.Random(0)}


# ── formats ──────────────────────────────────────────────────────────────────

def test_formats_tools_to_anthropic():
    t = FakeTools().schemas[0]
    assert formats.to_anthropic_tools([t]) == [{"name": "read_file", "description": "read_file", "input_schema": READ}]


def test_formats_history_to_anthropic_merges_tool_results_and_lifts_system():
    msgs = [{"role": "system", "content": "be brief"}, {"role": "user", "content": "read a and b"},
            {"role": "assistant", "content": "Reading.", "tool_calls": [
                {"id": "c1", "type": "function", "function": {"name": "read_file", "arguments": '{"path": "a.txt"}'}},
                {"id": "c2", "type": "function", "function": {"name": "list_files", "arguments": ""}}]},
            {"role": "tool", "tool_call_id": "c1", "content": "alpha"},
            {"role": "tool", "tool_call_id": "c2", "content": "a.txt"}]
    body = formats.to_anthropic_request(msgs, FakeTools().schemas[:1], model="m", max_tokens=99)
    assert body["system"] == "be brief" and body["model"] == "m" and body["max_tokens"] == 99
    assert [m["role"] for m in body["messages"]] == ["user", "assistant", "user"]
    asst = body["messages"][1]["content"]
    assert asst[0] == {"type": "text", "text": "Reading."}
    assert asst[1] == {"type": "tool_use", "id": "c1", "name": "read_file", "input": {"path": "a.txt"}}
    assert asst[2]["input"] == {}                           # an empty arguments string is {}
    assert body["messages"][2]["content"] == [
        {"type": "tool_result", "tool_use_id": "c1", "content": "alpha"},
        {"type": "tool_result", "tool_use_id": "c2", "content": "a.txt"}]
    assert body["tools"][0]["input_schema"] == READ


def test_formats_malformed_call_in_history_becomes_an_empty_input():
    msgs = [{"role": "user", "content": "send it"},
            {"role": "assistant", "content": "", "tool_calls": [
                {"id": "c1", "type": "function",
                 "function": {"name": "send_email", "arguments": '{"to": "x@acme.example", "subject": "s"'}},
                {"id": "c2", "type": "function", "function": {"name": "read_file", "arguments": '["a.txt"]'}}]},
            {"role": "tool", "tool_call_id": "c1", "content": "ERROR: send_email: arguments are not valid JSON"},
            {"role": "tool", "tool_call_id": "c2", "content": "ERROR: read_file: arguments must be a JSON object"}]
    body = formats.to_anthropic_request(msgs, [], model="m")      # run keeps refused calls in the history
    assert [b["input"] for b in body["messages"][1]["content"]] == [{}, {}], \
        "arguments that do not parse to an object become {}: the tool_result already says what was wrong"


def test_formats_history_without_system_or_tools_has_neither_key():
    body = formats.to_anthropic_request([{"role": "user", "content": "hi"}], [], model="m")
    assert "system" not in body and "tools" not in body


def test_formats_anthropic_response_to_chat_completions():
    resp = {"type": "message", "role": "assistant", "stop_reason": "tool_use",
            "content": [{"type": "text", "text": "Let me look."},
                        {"type": "tool_use", "id": "toolu_1", "name": "read_file", "input": {"path": "a.txt"}}],
            "usage": {"input_tokens": 321, "output_tokens": 45}}
    msg, usage = formats.from_anthropic_response(resp)
    assert msg["content"] == "Let me look."
    call = msg["tool_calls"][0]
    assert call["id"] == "toolu_1" and call["function"]["name"] == "read_file"
    assert json.loads(call["function"]["arguments"]) == {"path": "a.txt"}   # a string again, as Chat Completions has it
    assert usage == {"prompt_tokens": 321, "completion_tokens": 45}
    msg, _ = formats.from_anthropic_response({"content": [{"type": "text", "text": "done"}], "usage": {}})
    assert msg == {"role": "assistant", "content": "done"}


# ── schema ───────────────────────────────────────────────────────────────────

@pytest.mark.parametrize("raw,ok", [('{"path": "a"}', True), ({"path": "a"}, True), ("", True), (None, True),
                                    ('{"path": "a",}', False), ("{'path': 'a'}", False), ('{"path": "a"', False),
                                    ('["a"]', False), ("42", False)])
def test_schema_parse_arguments(raw, ok):
    args, err = parse_arguments(raw)
    hint = " (an empty string, or None for a call with no arguments key, means {})" if raw in ("", None) else ""
    assert (err is None) == ok, f"parse_arguments({raw!r}) returned the error {err!r}{hint}"
    if ok:
        assert isinstance(args, dict)
    else:
        assert args is None and ("JSON" in err or "object" in err)


def test_schema_errors_name_the_field_and_the_fix():
    assert check_arguments(SEND, {"to": "x", "subject": "y", "body": "z"}) == []
    errs = check_arguments(SEND, {"to": "x", "subject": 3, "cc": "boss"})
    assert "missing required field 'body'" in errs
    assert "'subject' must be string, got integer" in errs
    assert any(e.startswith("unexpected field 'cc'") and "to" in e for e in errs)


def test_schema_errors_come_in_the_documented_order():
    assert check_arguments(SEND, {"cc": "boss", "subject": 3}) == [
        "missing required field 'to'", "missing required field 'body'",              # required order
        "unexpected field 'cc' (allowed: body, subject, to)",                      # then the arguments' order
        "'subject' must be string, got integer"]                                   # then properties order


def test_schema_types_enum_and_arrays():
    s = {"type": "object", "properties": {"n": {"type": "integer"}, "p": {"enum": ["high", "low"]},
                                          "tags": {"type": "array", "items": {"type": "string"}}}}
    assert check_arguments(s, {"n": 3, "p": "low", "tags": ["a"]}) == []
    assert check_arguments(s, {"n": 3.0}) == []                     # 3.0 is an integer in JSON Schema
    assert check_arguments(s, {"n": True}) == ["'n' must be integer, got boolean"]
    assert check_arguments(s, {"p": "urgent"}) == ["'p' must be one of ['high', 'low'], got 'urgent'"]
    assert check_arguments(s, {"tags": ["a", 2]}) == ["'tags[1]' must be string, got integer"]


# ── retry ────────────────────────────────────────────────────────────────────

@pytest.mark.parametrize("err,want", [
    (httpx.ReadTimeout("slow"), "retry"), (httpx.ConnectError("refused"), "retry"),
    (httpx.RemoteProtocolError("hung up"), "retry"), (ModelHTTPError(429), "retry"), (ModelHTTPError(503), "retry"),
    (ModelHTTPError(500), "retry"), (ModelHTTPError(400), "fail"), (ModelHTTPError(401), "fail"),
    (ModelHTTPError(404), "fail"), (KeyError("choices"), "fail"), (ValueError("bad json"), "fail")])
def test_retry_classify(err, want):
    assert classify(err) == want


def test_retry_backoff_is_full_jitter_under_the_cap():
    rng = random.Random(1)
    for attempt, top in [(0, 0.5), (1, 1.0), (3, 4.0), (6, 8.0), (20, 8.0)]:
        xs = [backoff(attempt, base=0.5, cap=8.0, rng=rng) for _ in range(2000)]
        assert 0 <= min(xs) and max(xs) <= top
        assert abs(sum(xs) / len(xs) - top / 2) < 0.08 * top      # uniform, so the mean is half the ceiling


def test_retry_retries_then_succeeds_and_honours_retry_after():
    seq = [ModelHTTPError(503), ModelHTTPError(429, retry_after=7.0), "ok"]
    waits = []

    def fn():
        x = seq.pop(0)
        if isinstance(x, Exception):
            raise x
        return x
    assert call_with_retries(fn, max_attempts=4, sleep=waits.append, rng=random.Random(0)) == "ok"
    assert len(waits) == 2 and waits[0] <= 0.5 and waits[1] >= 7.0


def test_retry_fails_fast_on_a_client_error_and_gives_up_after_max_attempts():
    calls = []

    def bad():
        calls.append(1)
        raise ModelHTTPError(400)
    with pytest.raises(ModelHTTPError):
        call_with_retries(bad, **NO_SLEEP)
    assert len(calls) == 1
    calls.clear()

    def flaky():
        calls.append(1)
        raise httpx.ConnectError("down")
    with pytest.raises(httpx.ConnectError):
        call_with_retries(flaky, max_attempts=3, **NO_SLEEP)
    assert len(calls) == 3


# ── budget ───────────────────────────────────────────────────────────────────

def test_budget_steps_tokens_cost_seconds():
    now = [100.0]
    b = Budget(max_steps=3, max_tokens=1000, max_cost=0.01, max_seconds=30, price_in=2.0, price_out=10.0,
               clock=lambda: now[0])
    b.start()
    assert b.exceeded() is None
    b.charge({"prompt_tokens": 300, "completion_tokens": 50})
    assert b.exceeded() is None and b.spent()["steps"] == 1
    b.charge({"prompt_tokens": 600, "completion_tokens": 50})
    assert b.exceeded() == "tokens"                         # 1000 tokens: at the limit is out
    b2 = Budget(max_steps=2)
    b2.start()
    b2.charge({})
    b2.charge({})
    assert b2.exceeded() == "steps"
    b3 = Budget(max_cost=0.001, price_in=1.0, price_out=0.0)
    b3.start()
    b3.charge({"prompt_tokens": 1000, "completion_tokens": 0})
    assert b3.exceeded() == "cost"                          # 1000 tokens at 1 per million = 0.001
    b4 = Budget(max_seconds=30, clock=lambda: now[0])
    b4.start()
    now[0] += 31
    b4.start()                                              # a second start keeps the first
    assert b4.exceeded() == "seconds"


# ── parallel ─────────────────────────────────────────────────────────────────

def _calls(*specs):
    return [ToolCall(f"c{i}", n, a, None) for i, (n, a) in enumerate(specs)]


def test_parallel_reads_run_together_and_results_keep_call_order():
    tools = FakeTools(delay=0.2)
    calls = _calls(("read_file", {"path": "b.txt"}), ("read_file", {"path": "a.txt"}), ("list_files", {}))
    t0 = time.monotonic()
    out = execute(calls, tools, parallel_safe={"read_file", "list_files"})
    assert time.monotonic() - t0 < 0.45 and tools.peak == 3   # three 0.2 s reads in about 0.2 s
    assert [m["tool_call_id"] for m in out] == ["c0", "c1", "c2"]
    assert [m["content"] for m in out] == ["beta", "alpha", "a.txt\nb.txt"]
    assert all(m["role"] == "tool" for m in out)


def test_parallel_a_write_is_a_barrier():
    tools = FakeTools(delay=0.05)
    calls = _calls(("read_file", {"path": "a.txt"}), ("write_file", {"path": "a.txt", "content": "new"}),
                   ("read_file", {"path": "a.txt"}))
    out = execute(calls, tools, parallel_safe={"read_file"})
    assert [m["content"] for m in out] == ["alpha", "ok", "new"]
    events = [(e, n) for e, n, _ in tools.log]
    w = events.index(("start", "write_file"))
    assert events[w - 1] == ("end", "read_file") and events[w + 1] == ("end", "write_file")


def test_parallel_refused_and_failing_calls_become_text():
    tools = FakeTools()
    calls = [ToolCall("c0", "read_file", None, "ERROR: refused"), *_calls(("read_file", {"path": "zzz"}))]
    calls[1].id = "c1"
    out = execute(calls, tools, parallel_safe={"read_file"})
    assert out[0]["content"] == "ERROR: refused"
    assert out[1]["content"].startswith("ERROR: read_file failed: FileNotFoundError")
    assert [a for _, _, a in tools.log] == ["zzz", "zzz"]       # only the failing call ran; the refused one did not


def test_parallel_prepare_refuses_unknown_tools_and_bad_arguments():
    schemas = {t["function"]["name"]: t["function"]["parameters"] for t in FakeTools().schemas}
    p = prepare({"id": "x", "function": {"name": "delete_all", "arguments": "{}"}}, schemas)
    assert p.arguments is None and "no tool named 'delete_all'" in p.error
    p = prepare({"id": "x", "function": {"name": "read_file", "arguments": '{"path": "a.txt",}'}}, schemas)
    assert p.arguments is None and "not valid JSON" in p.error
    p = prepare({"id": "x", "function": {"name": "send_email", "arguments": '{"to": "a"}'}}, schemas)
    assert p.arguments is None and "missing required field 'subject'" in p.error


# ── structured ───────────────────────────────────────────────────────────────

def test_structured_extract_json_from_prose_and_fences():
    assert extract_json('{"a": 1}') == {"a": 1}
    assert extract_json('Sure! Here it is:\n```json\n{"a": [1, 2]}\n```\nAnything else?') == {"a": [1, 2]}
    assert extract_json('The answer is {"a": "x {y}"} as asked.') == {"a": "x {y}"}
    assert extract_json("Not this {broken, but this: [3]") == [3]
    with pytest.raises(ValueError):
        extract_json("no json here")


def test_structured_parse_final():
    s = {"type": "object", "properties": {"total": {"type": "integer"}}, "required": ["total"]}
    assert parse_final('{"total": 5}', s) == ({"total": 5}, [])
    assert parse_final('{"total": "5"}', s) == (None, ["'total' must be integer, got string"])
    assert parse_final("five", s) == (None, ["no JSON object or array in the reply"])


# ── stream ───────────────────────────────────────────────────────────────────

def _chunk(delta, finish=None):
    return {"choices": [{"index": 0, "delta": delta, "finish_reason": finish}]}


def test_stream_assembles_text():
    chunks = [_chunk({"role": "assistant", "content": "The "}), _chunk({"content": "total "}),
              _chunk({"content": "is 5."}), _chunk({}, "stop"), {"choices": [], "usage": {"prompt_tokens": 9}}]
    assert assemble(chunks) == {"role": "assistant", "content": "The total is 5."}


def test_stream_assembles_tool_call_fragments_by_index():
    tc = lambda i, **kw: _chunk({"tool_calls": [{"index": i, **kw}]})
    chunks = [tc(0, id="call_a", type="function", function={"name": "read_file", "arguments": ""}),
              tc(1, id="call_b", type="function", function={"name": "list_files", "arguments": "{}"}),
              tc(0, function={"arguments": '{"pa'}), tc(0, function={"arguments": 'th": "a.txt"}'}),
              _chunk({}, "tool_calls")]
    msg = assemble(chunks)
    assert msg["content"] == ""
    assert [c["id"] for c in msg["tool_calls"]] == ["call_a", "call_b"]
    assert json.loads(msg["tool_calls"][0]["function"]["arguments"]) == {"path": "a.txt"}
    assert msg["tool_calls"][1]["function"] == {"name": "list_files", "arguments": "{}"}


def test_stream_orders_calls_by_index_not_by_arrival():
    tc = lambda i, **kw: _chunk({"tool_calls": [{"index": i, **kw}]})
    chunks = [tc(1, id="call_b", type="function", function={"name": "list_files", "arguments": "{}"}),
              tc(0, id="call_a", type="function", function={"name": "read_file", "arguments": '{"path": "a.txt"}'}),
              _chunk({}, "tool_calls")]
    assert [c["id"] for c in assemble(chunks)["tool_calls"]] == ["call_a", "call_b"], \
        "index 1 arrived first, but tool calls go in index order (lesson 8, question 1)"


def test_stream_a_later_fragment_cannot_change_a_calls_id_or_name():
    tc = lambda i, **kw: _chunk({"tool_calls": [{"index": i, **kw}]})
    chunks = [tc(0, id="call_a", type="function", function={"name": "read_file", "arguments": '{"pa'}),
              tc(0, id="call_a", function={"arguments": 'th": '}),                     # a server that repeats the id
              tc(0, id="call_x", function={"name": "send_email", "arguments": '"a.txt"}'}),   # one that changes it
              _chunk({}, "tool_calls")]
    calls = assemble(chunks)["tool_calls"]
    assert len(calls) == 1 and (calls[0]["id"], calls[0]["function"]["name"]) == ("call_a", "read_file"), \
        "the id and name come from the first fragment that has them (lesson 8, question 3)"
    assert json.loads(calls[0]["function"]["arguments"]) == {"path": "a.txt"}


def test_stream_whole_calls_as_ollama_sends_them():
    chunks = [_chunk({"content": "", "tool_calls": [{"id": "c1", "index": 0, "type": "function",
                                                     "function": {"name": "read_file", "arguments": '{"path":"a"}'}}]}),
              _chunk({}, "tool_calls")]
    assert assemble(chunks)["tool_calls"][0]["function"]["arguments"] == '{"path":"a"}'


# ── loop ─────────────────────────────────────────────────────────────────────

def test_loop_answers_and_records_everything():
    tools = FakeTools()
    model = ScriptedClient([tool_calls(("read_file", '{"path": "a.txt"}'), ("read_file", '{"path": "b.txt"}')),
                            tool_call("send_email", to="m@acme.example", subject="s", body="alpha beta"),
                            answer("Sent.")])
    r = run("summarise", model, tools, retry=NO_SLEEP)
    assert (r.stop, r.answer) == ("answer", "Sent.")
    assert model.seen[0][0] == {"role": "system", "content": SYSTEM} and model.seen[0][1]["content"] == "summarise"
    assert [m["content"] for m in model.seen[1][-2:]] == ["alpha", "beta"]
    assert tools.sent == [{"to": "m@acme.example", "subject": "s", "body": "alpha beta"}]
    assert [c[0] for c in r.calls] == ["read_file", "read_file", "send_email"]
    assert r.usage["steps"] == 3 and r.usage["prompt_tokens"] == 300 and r.usage["completion_tokens"] == 60


def test_loop_malformed_arguments_go_back_to_the_model_and_the_tool_never_runs():
    tools = FakeTools()
    model = ScriptedClient([tool_call("send_email", raw='{"to": "x@acme.example", "subject": "s"'),
                            answer("Gave up.")])
    r = run("t", model, tools, retry=NO_SLEEP)
    assert r.stop == "answer" and tools.sent == []
    err = model.seen[1][-1]
    assert err["role"] == "tool" and "not valid JSON" in err["content"]
    assert r.calls[0][1] is None


def test_loop_stops_on_each_limit():
    loop_forever = [tool_call("list_files")] * 50
    r = run("t", ScriptedClient(loop_forever), FakeTools(), Budget(max_steps=4), retry=NO_SLEEP)
    assert r.stop == "steps" and r.usage["steps"] == 4
    r = run("t", ScriptedClient(loop_forever, usage={"prompt_tokens": 400, "completion_tokens": 100}), FakeTools(),
            Budget(max_steps=50, max_tokens=1200), retry=NO_SLEEP)
    assert r.stop == "tokens" and r.usage["steps"] == 3
    r = run("t", ScriptedClient(loop_forever), FakeTools(), Budget(max_steps=50, max_cost=0.00045, price_in=1.0),
            retry=NO_SLEEP)
    assert r.stop == "cost" and r.usage["steps"] == 5        # 100 prompt tokens a step at 1 per million


def test_loop_retries_model_failures_and_reports_a_permanent_one():
    model = ScriptedClient([ModelHTTPError(503), httpx.ReadTimeout("slow"), answer("ok")])
    r = run("t", model, FakeTools(), retry={"max_attempts": 3, **NO_SLEEP})
    assert r.stop == "answer" and model.calls == 3 and r.usage["steps"] == 1   # failed calls are not charged
    model = ScriptedClient([ModelHTTPError(503), ModelHTTPError(503), answer("ok")])
    r = run("t", model, FakeTools(), retry={"max_attempts": 2, **NO_SLEEP})
    assert (r.stop, model.calls) == ("error", 2), "run passes retry on to call_with_retries: max_attempts=2 is two calls"
    r = run("t", ScriptedClient([ModelHTTPError(401, "bad key")]), FakeTools(), retry=NO_SLEEP)
    assert r.stop == "error" and "401" in r.error


def test_loop_checks_the_final_answer_with_one_repair():
    s = {"type": "object", "properties": {"total": {"type": "integer"}}, "required": ["total"]}
    model = ScriptedClient([answer("About five."), answer('```json\n{"total": 5}\n```')])
    r = run("t", model, FakeTools(), answer_schema=s, retry=NO_SLEEP)
    assert (r.stop, r.data, r.repairs) == ("answer", {"total": 5}, 1)
    assert "JSON Schema" in model.seen[0][0]["content"]
    assert model.seen[1][-1]["role"] == "user" and "did not match" in model.seen[1][-1]["content"]
    r = run("t", ScriptedClient([answer("five"), answer("still five"), answer('{"total": 5}')]), FakeTools(),
            answer_schema=s, retry=NO_SLEEP)
    assert r.stop == "schema" and r.repairs == 1 and r.data is None


def test_loop_asks_for_a_chunked_reply_and_runs_it():
    chunks = [_chunk({"tool_calls": [{"index": 0, "id": "c", "type": "function",
                                      "function": {"name": "read_file", "arguments": '{"path"'}}]}),
              _chunk({"tool_calls": [{"index": 0, "function": {"arguments": ': "a.txt"}'}}]})]
    model = ScriptedClient([("chunks", chunks), answer("alpha")])     # raises unless asked with stream=True
    r = run("t", model, FakeTools(), stream=True, retry=NO_SLEEP)
    assert r.stop == "answer", f"run(stream=True) must pass stream=True to model.complete: {r.error}"
    assert r.calls[0][:2] == ("read_file", {"path": "a.txt"})


# ── live ─────────────────────────────────────────────────────────────────────

def _live_problem() -> str | None:
    """Why the live test cannot run, or None. It resets the lab, so it never runs on a default address."""
    if importlib.util.find_spec("agent") is None:
        return "needs Module 1's agent/ and lab, which come with the full kit"
    asked = os.environ.get("CHECK_E3_LIVE") or os.environ.get("AGENT_BASE_URL")
    if not (asked and os.environ.get("TOOLS_URL")):
        return ("not asked for: it resets the lab at TOOLS_URL, so it runs only with CHECK_E3_LIVE=1 and "
                "TOOLS_URL set to a lab that nothing else is using")
    from checks import lab
    if not lab.lab_is_up():
        return f"no lab answers at {lab.TOOLS_URL}: make lab-up, or set TOOLS_URL to yours"
    return lab.model_problem()


@pytest.mark.skipif(bool(os.environ.get("CHECK_E3_OFFLINE")), reason="CHECK_E3_OFFLINE is set")
def test_live_finishes_the_module_1_task():
    problem = _live_problem()
    if problem:
        pytest.skip(problem)
    from agent.agent import Tools
    from checks import lab
    from loop.client import ChatClient
    from loop.tasks import TASKS
    task = next(t for t in TASKS if t.id == "send-summary")
    tries = int(os.environ.get("CHECK_E3_TRIES", "3"))
    results = []
    for _ in range(tries):
        lab.reset()
        r = run(task.prompt, ChatClient(), Tools(), Budget(max_steps=10, max_tokens=80_000))
        results.append((r.stop, task.grade(r.answer or "")))
        if results[-1] == ("answer", True):
            break
    assert ("answer", True) in results, f"no passing run in {tries}: {results}"


def test_loop_system_prompt_can_be_replaced():
    model = ScriptedClient([answer("ok")])
    run("t", model, FakeTools(), system="Answer in Hebrew.", retry=NO_SLEEP)
    assert model.seen[0][0] == {"role": "system", "content": "Answer in Hebrew."}


def test_client_strips_thinking_that_lost_its_opening_tag():
    from loop.client import _clean
    assert _clean({"role": "assistant", "content": "<think>a</think> done"})["content"] == "done"
    assert _clean({"role": "assistant", "content": "the user wants x.\n</think>\n\nThe answer is 5."})["content"] == "The answer is 5."
