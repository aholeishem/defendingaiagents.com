"""E3 study: the agent loop, measured.  Provided.

  uv run python -m studies.loop_study faults            # model-free, seconds
  uv run python -m studies.loop_study herd              # model-free, seconds
  uv run python -m studies.loop_study growth            # model-free, instant
  uv run python -m studies.loop_study tasks reps=3      # live: lab and model server; 20 tasks x 2 loops x reps
  uv run python -m studies.loop_study tasks reps=1 fault=0.1 out=loop_faults   # live, with injected 503s
  uv run python -m studies.loop_study summary           # reads studies/out/loop_tasks.jsonl (out=...), no model
  uv run python -m studies.loop_study stream n=10       # live: time to first token, streamed and not
  uv run python -m studies.loop_study schema reps=2     # live: structured answers and repairs

Every number in the E3 lessons comes from here. Live parts write JSON lines to studies/out/ so that `summary` can
be re-run without the model.

  faults    a five-call task against a model server that fails each call with probability p: the run's success
            without retries (Module 1) and with up to k attempts, measured over many runs, beside (1 - p^k)^5
  herd      1,000 clients fail together and retry: peak load per 100 ms with no jitter and with full jitter
  growth    prompt tokens per step when every step re-sends the history: linear per step, quadratic per run
  tasks     the twenty tasks of loop/tasks.py, Module 1's loop against E3's, same model, server and settings;
            fault=0.1 makes each model call fail with that probability for both loops, out= names the file
  summary   success with Wilson intervals, the paired difference, crashes, tokens, seconds and pass^k
  stream    time to first token and to the last byte, for the same prompt streamed and not
  schema    four fact tasks and one CRM task with an answer schema: first-try conformance, repairs, final conformance

The live parts need Module 1's agent/ and lab (the full kit). tasks and schema reset the lab before every run, so
they run only when TOOLS_URL names it: use a lab that nothing else is using.
"""
from __future__ import annotations

import json
import random
import statistics as st
import sys
import time
from math import comb, sqrt
from pathlib import Path

OUT = Path(__file__).resolve().parent / "out"
Z = 1.959964


def wilson(k: int, n: int, z: float = Z) -> tuple[float, float]:
    if n == 0:
        return 0.0, 1.0
    p, d = k / n, 1 + z * z / n
    c, h = (p + z * z / (2 * n)) / d, z * sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, c - h), min(1.0, c + h)


def pct(x: float) -> str:
    return f"{100 * x:.1f}%"


def args(argv: list[str]) -> dict:
    return dict(a.split("=", 1) for a in argv if "=" in a)


# ── faults ───────────────────────────────────────────────────────────────────

class _Flaky:
    """Wraps a client: each call fails with probability p (a 503), independently."""

    def __init__(self, inner, p: float, rng: random.Random):
        self.inner, self.p, self.rng = inner, p, rng

    def complete(self, messages, tools, stream=False):
        from loop.client import ModelHTTPError
        if self.rng.random() < self.p:
            raise ModelHTTPError(503, "overloaded")
        return self.inner.complete(messages, tools, stream)


class _NoTools:
    schemas = [{"type": "function", "function": {"name": "list_files", "parameters": {"type": "object"}}}]

    def call(self, name, arguments):
        return "a.txt"


def faults(n: int = 4000, seed: int = 7) -> None:
    from loop.agent import run
    from loop.budget import Budget
    from loop.scripted import ScriptedClient, answer, tool_call
    rng = random.Random(seed)
    calls = 5                                   # four tool calls, then the answer
    print(f"A {calls}-call task, each call failing independently with probability p; {n} runs per cell.")
    print(f"  {'p':>5} {'attempts':>9} {'measured':>9} {'95% interval':>17} {'(1-p^k)^5':>10} {'calls/run':>10}")
    for p in (0.02, 0.05, 0.2):
        for k in (1, 2, 3, 4):
            ok, model_calls = 0, 0
            for _ in range(n):
                script = [tool_call("list_files", path=".") for _ in range(calls - 1)] + [answer("done")]
                flaky = _Flaky(ScriptedClient(script), p, rng)
                inner_calls = [0]
                orig = flaky.complete

                def counted(*a, _o=orig, **kw):
                    inner_calls[0] += 1
                    return _o(*a, **kw)
                flaky.complete = counted
                r = run("t", flaky, _NoTools(), Budget(max_steps=20),
                        retry={"max_attempts": k, "sleep": lambda s: None, "rng": rng})
                ok += r.stop == "answer"
                model_calls += inner_calls[0]
            lo, hi = wilson(ok, n)
            print(f"  {p:>5} {k:>9} {pct(ok / n):>9} {pct(lo):>8} to {pct(hi):>6} {pct((1 - p ** k) ** calls):>10} "
                  f"{model_calls / n:>10.2f}")


# ── herd ─────────────────────────────────────────────────────────────────────

def herd(clients: int = 1000, seed: int = 3) -> None:
    from loop.retry import backoff
    rng = random.Random(seed)
    print(f"{clients} clients fail together at t=0 and each retries 4 times (base 0.5 s, cap 8 s); "
          "load counted in 100 ms buckets.")
    for name, jitter in (("no jitter", False), ("full jitter", True)):
        t = [0.0] * clients
        peaks = []
        for attempt in range(4):
            t = [x + (backoff(attempt, rng=rng) if jitter else min(8.0, 0.5 * 2 ** attempt)) for x in t]
            buckets: dict[int, int] = {}
            for x in t:
                buckets[int(x * 10)] = buckets.get(int(x * 10), 0) + 1
            peaks.append(max(buckets.values()))
        print(f"  {name:12} peak requests in one 100 ms bucket, retries 1-4: {peaks}")


# ── growth ───────────────────────────────────────────────────────────────────

def growth(system: int = 600, task: int = 40, call: int = 30, result: int = 400, steps: int = 10) -> None:
    print(f"Prompt tokens re-sent at each step (system+tools {system}, task {task}, each tool call {call}, "
          f"each result {result}):")
    total, rows = 0, []
    for s in range(1, steps + 1):
        prompt = system + task + (s - 1) * (call + result)
        total += prompt
        rows.append((s, prompt, total))
    for s, p, t in rows:
        if s in (1, 2, 5, 10):
            print(f"  step {s:>2}: prompt {p:>6,}  run so far {t:>7,}")
    print(f"  a run of n steps sends about n*(S+T) + (C+R)*n(n-1)/2: quadratic in n; at {steps} steps "
          f"{(call + result) * steps * (steps - 1) // 2:,} of the {total:,} are history")


# ── tasks (live) ─────────────────────────────────────────────────────────────

def _live(part: str, resets: bool) -> None:
    """Stop with a reason unless the live part can run: Module 1's agent/ is there and, for a part that resets the
    lab, TOOLS_URL names the lab explicitly (a reset never goes to a default address)."""
    import importlib.util
    import os
    if importlib.util.find_spec("agent") is None:
        sys.exit(f"{part} needs Module 1's agent/ and lab, which come with the full kit")
    if resets and "TOOLS_URL" not in os.environ:
        sys.exit(f"{part} resets the lab before every run: set TOOLS_URL to a lab that nothing else is using")


def tasks(reps: int = 3, only: str = "", fault: str = "0", out: str = "loop_tasks") -> None:
    """fault=0.1 wraps the model client so that each call fails with a 503 with that probability, the same for both
    loops (lesson 5, live). out names the JSON-lines file in studies/out/."""
    _live("tasks", resets=True)
    from agent.agent import Tools
    from agent.agent import run as m1_run
    from checks import lab
    from loop.agent import run as e3_run
    from loop.budget import Budget
    from loop.client import MODEL, ChatClient, LegacyAdapter
    from loop.tasks import TASKS
    problem = lab.model_problem()
    if problem or not lab.lab_is_up():
        sys.exit(problem or "the lab is not running")
    OUT.mkdir(exist_ok=True)
    path = OUT / f"{out}.jsonl"
    p_fault, rng = float(fault), random.Random(5)
    todo = [t for t in TASKS if not only or t.id in only.split(",")]
    print(f"{len(todo)} tasks x 2 loops x {reps} reps on {MODEL}; appending to {path}")
    with path.open("a") as f:
        for rep in range(reps):
            for t in todo:
                for loop_name in ("m1", "e3"):
                    lab.reset()
                    client, t0 = ChatClient(), time.monotonic()
                    if p_fault:
                        client = _Flaky(client, p_fault, rng)
                    row = {"task": t.id, "kind": t.kind, "loop": loop_name, "rep": rep, "model": MODEL,
                           "fault": p_fault, "at": time.strftime("%Y-%m-%dT%H:%M:%S")}
                    try:
                        if loop_name == "m1":
                            m = LegacyAdapter(client)
                            out = m1_run(t.prompt, m, Tools(), max_steps=10, log=lambda *_: None)
                            row |= {"stop": "steps" if out.startswith("[stopped") else "answer", "answer": out,
                                    "steps": m.calls, **m.usage}
                        else:
                            r = e3_run(t.prompt, client, Tools(), Budget(max_steps=10))
                            row |= {"stop": r.stop, "answer": r.answer or "", "steps": r.usage["steps"],
                                    "prompt_tokens": r.usage["prompt_tokens"],
                                    "completion_tokens": r.usage["completion_tokens"],
                                    "refused": sum(1 for c in r.calls if c[1] is None), "error": r.error}
                    except Exception as e:  # noqa: BLE001  (Module 1's loop has no error handling: a crash is data)
                        row |= {"stop": "crash", "answer": "", "error": f"{e.__class__.__name__}: {e}"[:300]}
                    row["seconds"] = round(time.monotonic() - t0, 2)
                    row["passed"] = bool(row["stop"] == "answer" and t.grade(row["answer"]))
                    f.write(json.dumps(row) + "\n")
                    f.flush()
                    print(f"  rep {rep} {t.id:16} {loop_name}: {row['stop']:7} {'pass' if row['passed'] else 'FAIL'} "
                          f"{row['seconds']:6.1f}s")
    summary(out)


def pass_hat_k(c: int, n: int, k: int) -> float:
    """Unbiased estimate of P(all k of k fresh tries pass), from c passes in n tries (Yao et al., 2024)."""
    return comb(c, k) / comb(n, k) if n >= k else float("nan")


def summary(out: str = "loop_tasks") -> None:
    rows = [json.loads(x) for x in (OUT / f"{out}.jsonl").read_text().splitlines() if x.strip()]
    models = sorted({r["model"] for r in rows})
    print(f"{len(rows)} runs, model(s) {', '.join(models)}, {rows[0]['at'][:10]} to {rows[-1]['at'][:10]}")
    by = {lp: [r for r in rows if r["loop"] == lp] for lp in ("m1", "e3")}
    print(f"  {'loop':5} {'runs':>5} {'passed':>7} {'rate':>7} {'95% Wilson':>17} {'crash':>6} {'limit':>6} "
          f"{'tokens/run':>11} {'s/run':>7} {'steps':>6}")
    for lp, rs in by.items():
        k, n = sum(r["passed"] for r in rs), len(rs)
        lo, hi = wilson(k, n)
        tok = [r.get("prompt_tokens", 0) + r.get("completion_tokens", 0) for r in rs if r["stop"] != "crash"]
        print(f"  {lp:5} {n:>5} {k:>7} {pct(k / n):>7} {pct(lo):>8} to {pct(hi):>6} "
              f"{sum(r['stop'] == 'crash' for r in rs):>6} {sum(r['stop'] in ('steps', 'tokens') for r in rs):>6} "
              f"{st.mean(tok) if tok else 0:>11,.0f} {st.mean(r['seconds'] for r in rs):>7.1f} "
              f"{st.mean(r.get('steps', 0) for r in rs if r['stop'] != 'crash'):>6.1f}")
    # Paired by (task, rep): only E3 passes, only M1 passes.
    pair = {}
    for r in rows:
        pair.setdefault((r["task"], r["rep"]), {})[r["loop"]] = r["passed"]
    both = [v for v in pair.values() if len(v) == 2]
    b = sum(1 for v in both if v["e3"] and not v["m1"])
    c = sum(1 for v in both if v["m1"] and not v["e3"])
    print(f"  paired runs {len(both)}: only E3 passed {b}, only M1 passed {c}; "
          f"exact McNemar two-sided p = {_mcnemar(b, c):.3f}")
    # Paired task-level bootstrap of the difference in pass rate (tasks are the unit that clusters).
    tasks_ = sorted({r["task"] for r in rows})
    rate = {(t, lp): st.mean(r["passed"] for r in rows if r["task"] == t and r["loop"] == lp) for t in tasks_
            for lp in ("m1", "e3") if any(r["task"] == t and r["loop"] == lp for r in rows)}
    diffs = [rate[(t, "e3")] - rate[(t, "m1")] for t in tasks_ if (t, "e3") in rate and (t, "m1") in rate]
    rng = random.Random(11)
    boots = sorted(st.mean(rng.choice(diffs) for _ in diffs) for _ in range(5000))
    print(f"  difference E3 - M1 in pass rate, task-clustered bootstrap: {st.mean(diffs):+.3f} "
          f"(95% {boots[124]:+.3f} to {boots[4874]:+.3f}) over {len(diffs)} tasks")
    print("  by kind (E3 vs M1 pass rate):")
    for kind in ("fact", "combine", "write", "send", "crm"):
        e = [r["passed"] for r in by["e3"] if r["kind"] == kind]
        m = [r["passed"] for r in by["m1"] if r["kind"] == kind]
        if e and m:
            print(f"    {kind:8} {pct(st.mean(e)):>7} vs {pct(st.mean(m)):>7}  (n = {len(e)} each)")
    crashes = [r["error"] for r in by["m1"] if r["stop"] == "crash"]
    if crashes:
        print("  Module 1 crashes:", "; ".join(sorted({c.split(':')[0] for c in crashes})))
    refused = sum(r.get("refused", 0) for r in by["e3"])
    print(f"  E3 refused tool calls (bad arguments or unknown tool): {refused} in {len(by['e3'])} runs")
    reps = max(r["rep"] for r in rows) + 1
    if reps >= 2:
        for lp, rs in by.items():
            per = {}
            for r in rs:
                per.setdefault(r["task"], []).append(r["passed"])
            for k in range(1, reps + 1):
                vals = [pass_hat_k(sum(v), len(v), k) for v in per.values() if len(v) >= k]
                print(f"  {lp} pass^{k} = {st.mean(vals):.3f}", end="")
            print()


def _mcnemar(b: int, c: int) -> float:
    n = b + c
    if n == 0:
        return 1.0
    tail = sum(comb(n, i) for i in range(0, min(b, c) + 1)) / 2 ** n
    return min(1.0, 2 * tail)


# ── stream (live) ────────────────────────────────────────────────────────────

def stream(n: int = 10) -> None:
    _live("stream", resets=False)
    from agent.agent import Tools
    from loop.client import ChatClient
    client, tools = ChatClient(), Tools()
    msgs = [{"role": "user", "content": "Read notes/q3-report.txt, then summarise it in one sentence."}]
    rows = {False: [], True: []}
    for i in range(n):
        for s in (False, True):
            r = client.complete(msgs, tools.schemas, stream=s)
            rows[s].append((r.ttft, r.seconds, r.usage.get("completion_tokens", 0),
                            bool(r.message.get("tool_calls"))))
    OUT.mkdir(exist_ok=True)
    (OUT / "loop_stream.json").write_text(json.dumps({str(k): v for k, v in rows.items()}))
    for s, rs in rows.items():
        ttft = [x[0] for x in rs if x[0] is not None]
        print(f"  {'streamed' if s else 'not streamed':13} total {st.median(x[1] for x in rs):5.1f} s median; "
              f"first byte {st.median(ttft) if ttft else float('nan'):5.1f} s median; "
              f"completion tokens {st.median(x[2] for x in rs):.0f} median; tool call in {sum(x[3] for x in rs)}/{n}")


# ── schema (live) ────────────────────────────────────────────────────────────

ANSWER = {"type": "object", "properties": {"answer": {"type": "string"}, "source": {"type": "string"}},
          "required": ["answer", "source"], "additionalProperties": False}


def schema(reps: int = 2) -> None:
    _live("schema", resets=True)
    from agent.agent import Tools
    from checks import lab
    from loop.agent import run
    from loop.budget import Budget
    from loop.client import ChatClient
    from loop.tasks import TASKS
    facts = [t for t in TASKS if t.kind == "fact"] + [t for t in TASKS if t.id == "crm-name"]
    rows = []
    for _ in range(reps):
        for t in facts:
            lab.reset()
            r = run(t.prompt, ChatClient(), Tools(), Budget(max_steps=10), answer_schema=ANSWER)
            rows.append({"task": t.id, "stop": r.stop, "repairs": r.repairs,
                         "passed": r.stop == "answer" and t.grade(json.dumps(r.data or {}))})
            print(f"  {t.id:16} {r.stop:7} repairs {r.repairs} {'pass' if rows[-1]['passed'] else 'FAIL'}")
    OUT.mkdir(exist_ok=True)
    (OUT / "loop_schema.jsonl").write_text("\n".join(json.dumps(x) for x in rows) + "\n")
    n = len(rows)
    first = sum(1 for x in rows if x["stop"] == "answer" and x["repairs"] == 0)
    final = sum(1 for x in rows if x["stop"] == "answer")
    print(f"  conformed first time {first}/{n}; after one repair {final}/{n}; correct and conforming "
          f"{sum(x['passed'] for x in rows)}/{n}")


PARTS = {"faults": faults, "herd": herd, "growth": growth, "tasks": tasks, "summary": summary, "stream": stream,
         "schema": schema}

if __name__ == "__main__":
    names = [a for a in sys.argv[1:] if "=" not in a] or ["faults", "herd", "growth"]
    kw = args(sys.argv[1:])
    for name in names:
        print(f"── {name}")
        fn = PARTS[name]
        PARTS[name](**{k: (int(v) if v.isdigit() else v) for k, v in kw.items()
                       if k in fn.__code__.co_varnames[:fn.__code__.co_argcount]})
