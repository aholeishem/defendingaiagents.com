# ערכת התצוגה המקדימה של E3: לולאת הסוכן מאפס

ערכה לשלבים 1 עד 8 של הבנייה ב־E3, מתוך התצוגה המקדימה החינמית של *בניית סוכני AI*:
https://defendingaiagents.com/he/learn/e03-agent-loop/build.html

צריך Python 3.11 ומעלה ואת [uv](https://docs.astral.sh/uv/). שום דבר כאן לא צריך מודל,
Docker או רשת אחרי ההתקנה הראשונה של `uv`, ושום דבר כאן לא פונה למעבדה.

```bash
make check-E3                        # נכשל: NotImplementedError ב־loop/
uv run pytest checks/test_checkE3.py -k schema    # הבדיקות של שלב אחד (הקבוצות למטה)
make loop-study PARTS=herd           # חלקי המחקר שלא צריכים מודל: herd, growth, faults
```

בלי make: `uv run pytest checks/test_checkE3.py`.

מממשים שמונה חלקים ב־`loop/` (עמוד הבנייה מפרט אותם), חלק אחד בכל שלב. הקבוצה של כל שלב
מריצה בדיוק את הבדיקות שלו: `-k schema` (שלב 1), `formats` (2), `parallel` (3), `retry` (4),
`budget` (5), `structured` (6), `stream` (7), `loop` (8). כשכל הבדיקות עוברות, שלבים 1 עד 8
מאחוריכם, ורק הבדיקה החיה מדולגת. שלבים 9 ו־10 מריצים את הלולאה שלכם מול המעבדה של מודול 1
ומודל מקומי, והם צריכים את ערכת הקורס המלאה, שתגיע עם הקורס.
