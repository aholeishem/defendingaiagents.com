# ערכת התצוגה המקדימה של E3: לולאת הסוכן מאפס

הערכה לשלבים 1 עד 7 של הבנייה ב־E3, מתוך התצוגה המקדימה החינמית של *בניית סוכני AI*:
https://defendingaiagents.com/he/learn/e03-agent-loop/build.html

צריך Python 3.11 ומעלה ואת [uv](https://docs.astral.sh/uv/). שום דבר כאן לא צריך מודל,
Docker או רשת אחרי ההתקנה הראשונה של `uv`.

```bash
make check-E3                        # נכשל: NotImplementedError ב־loop/
uv run pytest checks/test_checkE3.py -k schema    # קבוצה אחת בכל פעם
make loop-study PARTS=faults         # וגם herd, growth: חלקי המחקר שלא צריכים מודל
```

בלי make: `CHECK_E3_OFFLINE=1 uv run pytest checks/test_checkE3.py`.

מממשים שמונה חלקים ב־`loop/` (עמוד הבנייה מפרט אותם). כשכל הבדיקות עוברות, שלבים 1 עד 7
מאחוריכם. שלבים 8 ו־9 מריצים את הלולאה שלכם מול המעבדה של מודול 1 ומודל מקומי, והם
צריכים את ערכת הלימוד המלאה, שתגיע עם הקורס.
