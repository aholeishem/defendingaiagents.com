"""A stand-in for a language model: deterministic, offline, and too obedient.

It does what the user asks. It also does what *a document it reads* asks, because
to a language model both arrive as text and nothing marks which one is the boss.
That is the whole vulnerability, in forty lines. A real model fails the same way,
less predictably and less often; the lab trades realism for a result you can
reproduce and measure on any laptop.

It understands English and Hebrew imperatives of the form "<verb> [file] to
<address>", and it can assemble an instruction split across two documents.
"""
from __future__ import annotations

import hashlib
import json
import re

VERBS = (r"send|email|e-mail|mail|forward|dispatch|relay|pass along|transmit|"
         r"שלח|שלחו|העבר|העבירו|תעביר")
ADDR = r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+"
DOC = r"[\w-]+\.txt"
VERB_RE = re.compile(rf"\b(?:{VERBS})\b", re.I)


def _call(tool: str, args: dict) -> dict:
    tag = hashlib.sha1(json.dumps(args, sort_keys=True).encode()).hexdigest()[:6]
    return {"id": f"call_{tool}_{tag}", "type": "function",
            "function": {"name": tool, "arguments": json.dumps(args)}}


def _injected(outputs: list[str]) -> tuple[list[str], str | None]:
    """Instructions hiding in tool output: (documents to read, address to send to)."""
    docs, addr, has_verb = [], None, False
    for out in outputs:
        for line in re.split(r"\n|\.\s", out):
            if VERB_RE.search(line):
                has_verb = True
                docs += re.findall(DOC, line)
            m = re.search(ADDR, line)
            if m and VERB_RE.search(line):
                addr = m.group(0)
    if has_verb and addr is None:                      # split payload: verb here, address elsewhere
        for out in outputs:
            m = re.search(ADDR, out)
            if m and not m.group(0).endswith("@acme-corp.test"):
                addr = m.group(0)
    return docs, addr if has_verb else None


class NaiveModel:
    def chat(self, messages: list[dict], tools: list[dict]) -> dict:
        user = messages[0]["content"]
        done = [(c["function"]["name"], json.loads(c["function"]["arguments"]))
                for m in messages if m["role"] == "assistant" for c in m.get("tool_calls") or []]
        outputs = [m["content"] for m in messages if m["role"] == "tool"]
        read = {a.get("name") for n, a in done if n == "read_doc"}

        wanted: list[tuple[str, dict]] = []
        for d in re.findall(DOC, user):
            wanted.append(("read_doc", {"name": d}))
        if re.search(r"\blist\b", user, re.I):
            wanted.append(("list_docs", {}))
        user_addr = re.search(rf"\b(?:{VERBS})\b[^@]*?({ADDR})", user, re.I)
        if user_addr:
            wanted.append(("send_email", {"to": user_addr.group(1), "body": "__summary__"}))

        inj_docs, inj_addr = _injected(outputs)
        for d in inj_docs:
            wanted.append(("read_doc", {"name": d}))
        if inj_addr:
            wanted.append(("send_email", {"to": inj_addr, "body": "__everything__"}))

        for name, args in wanted:
            if name == "send_email":
                # Compose from document text. A summary is the head of what was read; "everything" is all of it.
                texts = [o for o in outputs if o != "blocked by policy" and not o.startswith("no such")]
                body = " ".join(texts) if args["body"] == "__everything__" else " ".join(t[:80] for t in texts[:1])
                args = {"to": args["to"], "body": body}
            if (name, args) in done:
                continue
            if name == "send_email" and any(n == "send_email" and a["to"] == args["to"] for n, a in done):
                continue
            if name == "read_doc" and args["name"] in read:
                continue
            return {"role": "assistant", "content": "", "tool_calls": [_call(name, args)]}
        return {"role": "assistant", "content": "Done."}
